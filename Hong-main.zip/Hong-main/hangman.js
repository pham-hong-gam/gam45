const wordDisplay = document.querySelector(".word-display");
const guessesText = document.querySelector(".guesses-text b");
const keyboardDiv = document.querySelector(".keyboard");
const hangmanImage = document.querySelector(".hangman-box img");
const gameModal = document.querySelector(".game-modal");
const playAgainBtn = gameModal.querySelector("button");

let currentWord, correctLetters, wrongGuessCount;
const maxGuesses = 6;

const generateKeyboard = () => {
  keyboardDiv.innerHTML = "";
  for (let i = 97; i <= 122; i++) {
    const btn = document.createElement("button");
    const letter = String.fromCharCode(i);
    btn.innerText = letter;
    btn.addEventListener("click", (e) => initGame(e.target, letter));
    keyboardDiv.appendChild(btn);
  }
};

const resetGame = () => {
  correctLetters = [];
  wrongGuessCount = 0;
  hangmanImage.src = `images/hangman-0.svg`;
  guessesText.innerText = `${wrongGuessCount} / ${maxGuesses}`;
  wordDisplay.innerHTML = currentWord.split("").map(() => `<li class="letter"></li>`).join("");
  document.querySelectorAll(".keyboard button").forEach(btn => btn.disabled = false);
  gameModal.classList.remove("show");
};

const getRandomWord = () => {
  const { word, hint } = wordList[Math.floor(Math.random() * wordList.length)];
  currentWord = word;
  document.querySelector(".hint-text b").innerText = hint;
  resetGame();
};

const gameOver = (isVictory) => {
  const modalText = isVictory ? "You found the word:" : "The correct word was:";
  gameModal.querySelector("img").src = `images/${isVictory ? 'victory' : 'lost'}.gif`;
  gameModal.querySelector("h4").innerText = isVictory ? "Congrats!" : "Game Over!";
  gameModal.querySelector("p").innerHTML = `${modalText} <b>${currentWord}</b>`;
  gameModal.classList.add("show");
};

const initGame = (button, clickedLetter) => {
  button.disabled = true;
  if (currentWord.includes(clickedLetter)) {
    [...currentWord].forEach((letter, index) => {
      if (letter === clickedLetter) {
        correctLetters.push(letter);
        const li = wordDisplay.querySelectorAll("li")[index];
        li.innerText = letter;
        li.classList.add("guessed");
      }
    });
  } else {
    wrongGuessCount++;
    hangmanImage.src = `images/hangman-${wrongGuessCount}.svg`;
  }
  guessesText.innerText = `${wrongGuessCount} / ${maxGuesses}`;

  const allGuessed = wordDisplay.querySelectorAll("li.guessed").length === currentWord.length;
  if (wrongGuessCount === maxGuesses) return gameOver(false);
  if (allGuessed) return gameOver(true);
};

document.addEventListener("DOMContentLoaded", () => {
  generateKeyboard();
  getRandomWord();
  playAgainBtn.addEventListener("click", getRandomWord);
});
